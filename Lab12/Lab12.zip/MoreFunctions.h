#ifndef LA12_MoreFunctions_h
#define LA12_MoreFunctions_h

#include <iostream>

namespace MyLib {
    void f(){
        std::cout << "f" << std::endl;
    }
    
    void someFunction(){
        std::cout << "someFunction\n";
    }
}


#endif