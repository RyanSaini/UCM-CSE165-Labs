#include <iostream>
#include "MoreFunctions.h"


using namespace MyLib;

int main(int argc, const char * argv[])
{
    f();
    someFunction();
    return 0;
}