#pragma once
#include <iostream>

using namespace std;

	void triple(int &num){
		num = num * 3;
	}

